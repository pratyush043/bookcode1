# FoodWaste_Management
It's a project in which i have used HTML, CSS and JavaScript. It has also used CSS library as well as Netbeans and MySQL tool to create backend but for security purpose code of the backend has not been uploaded. 

This project is being made to reduce foodwaste.
